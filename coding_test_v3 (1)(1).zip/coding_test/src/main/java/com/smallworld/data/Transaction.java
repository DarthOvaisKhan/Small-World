package com.smallworld.data;

public class Transaction {
    // Represent your transaction data here.
}
